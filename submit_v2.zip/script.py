"""
평가 서버가 실행하는 추론 코드.

서버는 이 zip 을 풀고 python script.py 를 실행한다.
  입력:  ./data/test.csv, ./data/sample_submission.csv  (서버가 넣어줌, 읽기전용)
  출력:  ./output/submission.csv                          (반드시 이 경로/이름)

각 행은 독립적으로 예측한다. test.csv 의 다른 행을 이용한 통계·인코딩은
규정 위반이므로 절대 만들지 않는다 (학습 때 저장한 값만 사용).
"""
import json
import os

import joblib
import numpy as np
import pandas as pd

ID, TARGET = "row_id", "control_success"
DATA_DIR = "./data"
MODEL_DIR = "./model"
OUT_PATH = "./output/submission.csv"

# ── 2025 드리프트 보정 강도 (0=끄기, 1=완전 이동) ──
# 모델 예측 평균을 train으로 외삽한 2025 성공률 쪽으로 이만큼 당긴다.
SHIFT_STRENGTH = 0.5


def load_meta():
    with open(f"{MODEL_DIR}/meta.json", encoding="utf-8") as f:
        return json.load(f)


def encode(df, meta):
    df = df.copy()
    for c in meta["cat_cols"]:
        if c in df.columns:
            m = meta["cat_maps"][c]
            df[c] = df[c].astype(str).map(m)
            df[c] = df[c].fillna(-1).astype(int)
    return df


def main():
    print("Load model & meta...")
    model = joblib.load(f"{MODEL_DIR}/model.pkl")
    calibrator = joblib.load(f"{MODEL_DIR}/calibrator.pkl")
    meta = load_meta()
    feats = meta["features"]

    print("Load test data...")
    test = pd.read_csv(f"{DATA_DIR}/test.csv", encoding="utf-8-sig")
    sub = pd.read_csv(f"{DATA_DIR}/sample_submission.csv", encoding="utf-8-sig")
    print(f" test={len(test)} submission={len(sub)}")

    X = encode(test[feats], meta)

    print("Inference...")
    p = model.predict_proba(X)[:, 1]
    p = calibrator.predict(p)                       # isotonic 보정

    # 드리프트 보정: 예측 평균을 2025 외삽 성공률 쪽으로 당긴다.
    # 각 행 독립 — test 를 보지 않고 train 에서 온 상수(rate_2025)만 사용.
    cur_mean = p.mean()
    target_mean = meta["rate_2025"]
    p = p + SHIFT_STRENGTH * (target_mean - cur_mean)
    p = np.clip(p, 1e-6, 1 - 1e-6)
    print(f" 예측평균 {cur_mean:.4f} → 보정후 {p.mean():.4f} (목표 {target_mean:.4f})")

    pred_map = dict(zip(test[ID], p))
    sub[TARGET] = [pred_map.get(r, 0.5) for r in sub[ID]]

    os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
    sub.to_csv(OUT_PATH, index=False, encoding="utf-8")
    print(f"Saved: {OUT_PATH} (rows={len(sub)})")


if __name__ == "__main__":
    main()
