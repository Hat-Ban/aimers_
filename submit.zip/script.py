# script.py — 제출용 추론 코드 (submit.zip 최상위)
# ------------------------------------------------------------
# 평가 서버 실행 구조:
#   submit.zip/
#     ├── model/model.pkl   ← train.py 가 만든 번들
#     ├── script.py         ← 이 파일
#     ├── requirements.txt
#     ├── data/             ← 평가 서버가 주입 (읽기 전용)
#     └── output/submission.csv  ← 반드시 여기에 저장
#
# ※ build_features() 는 train.py 에서도 import 해서 쓴다.
#   (학습/추론 전처리 불일치 방지 — 단일 진실 공급원)
# ------------------------------------------------------------
import os

import joblib
import numpy as np
import pandas as pd

ID_COL = "row_id"
TARGET_COL = "control_success"

# 원본 범주형 컬럼 (pandas category dtype 으로 변환 → HistGB 가 네이티브 처리)
RAW_CAT_COLS = [
    "top_bottom",
    "game_type",
    "base_state",
    "pitcher_hand",
    "batter_hand",
    "pitcher_team_id",
    "batter_team_id",
]

# 모델 입력에서 제외할 컬럼
# - row_id: 식별자
# - pitcher_id / batter_id: 고카디널리티 ID. 선수 개인 정보는 asof_* 가 이미 담고 있고,
#   raw ID 를 그대로 넣으면 과적합 + 미지 선수 대응 불가 → 베이스라인에서는 제외.
DROP_COLS = [ID_COL, "pitcher_id", "batter_id"]


# =======================
# 피처 엔지니어링
# =======================

def _shrink(rate, n, prior, k):
    """표본 수 기반 베이지안 축소(shrinkage).

    표본이 적은 선수(cold-start)의 rate 를 전체 평균(prior)쪽으로 당겨준다.
    n=0 이면 정확히 prior 가 된다.
    """
    n = pd.to_numeric(n, errors="coerce").fillna(0.0)
    r = pd.to_numeric(rate, errors="coerce").fillna(prior)
    return (r * n + prior * k) / (n + k)


def build_features(df, cfg):
    """학습/추론 공통 전처리. 행 단위로만 계산 → 평가 데이터 행간 정보 사용 없음."""
    p = cfg["priors"]
    k = cfg["shrink_k"]
    out = pd.DataFrame(index=df.index)

    # ---- 1) 원본 수치 피처 그대로 통과 ----
    passthrough = [c for c in df.columns
                   if c not in DROP_COLS + RAW_CAT_COLS + [TARGET_COL]]
    for c in passthrough:
        out[c] = pd.to_numeric(df[c], errors="coerce")

    # ---- 2) 볼카운트 파생 ----
    b = out["balls_before"]
    s = out["strikes_before"]
    out["count_state"] = b * 3 + s                 # 0~11 고유 카운트 상태
    out["count_diff"] = s - b                      # +면 투수 유리
    out["is_two_strike"] = (s == 2).astype("int8")
    out["is_three_ball"] = (b == 3).astype("int8")
    out["is_full_count"] = ((b == 3) & (s == 2)).astype("int8")
    out["is_first_pitch"] = ((b == 0) & (s == 0)).astype("int8")
    # 투수가 유리하면 유인구(존 밖 유도) → 제구 성공 정의와 직결되는 핵심 신호
    out["pitcher_ahead"] = (s > b).astype("int8")

    # ---- 3) 상황/압박 파생 ----
    out["abs_score_diff"] = out["score_diff_pitcher_team"].abs()
    out["is_blowout"] = (out["abs_score_diff"] >= 5).astype("int8")
    out["is_close_game"] = (out["abs_score_diff"] <= 1).astype("int8")
    out["we_diff"] = out["home_win_expectancy"] - out["away_win_expectancy"]
    out["log_li"] = np.log1p(out["li"].clip(lower=0))
    out["is_late_inning"] = (out["inning"] >= 7).astype("int8")
    out["scoring_position"] = (
        (out["runner_on_2b"] > 0) | (out["runner_on_3b"] > 0)).astype("int8")
    # 주자 있으면 세트포지션 → 제구 난이도 변화
    out["has_runner"] = (out["num_runners_on"] > 0).astype("int8")
    out["risk_situation"] = out["scoring_position"] * out["is_close_game"]

    # ---- 4) asof_* 축소 보정 (cold-start 안정화) ----
    pn = df["asof_pitcher_n"]
    bn = df["asof_batter_n"]
    mn = df["asof_pitcher_pitchmix_n"]

    for col, prior_key in [
        ("asof_pitcher_success_rate", "p_success"),
        ("asof_pitcher_reverse_rate", "p_reverse"),
        ("asof_pitcher_middle_rate", "p_middle"),
        ("asof_pitcher_ball_rate", "p_ball"),
        ("asof_pitcher_strike_rate", "p_strike"),
    ]:
        out[col + "_sh"] = _shrink(df[col], pn, p[prior_key], k)

    for col, prior_key in [
        ("asof_batter_success_rate", "b_success"),
        ("asof_batter_middle_rate", "b_middle"),
    ]:
        out[col + "_sh"] = _shrink(df[col], bn, p[prior_key], k)

    for col, prior_key in [
        ("asof_pitcher_fastball_rate", "p_fastball"),
        ("asof_pitcher_breaking_rate", "p_breaking"),
        ("asof_pitcher_offspeed_rate", "p_offspeed"),
    ]:
        out[col + "_sh"] = _shrink(df[col], mn, p[prior_key], k)

    # ---- 5) 최근 폼 (직전 N경기 - 통산) ----
    base_succ = out["asof_pitcher_success_rate_sh"]
    base_mid = out["asof_pitcher_middle_rate_sh"]
    for w in (1, 3, 5):
        c = f"asof_pitcher_prev{w}_game_success_rate"
        out[f"form_succ_{w}"] = pd.to_numeric(df[c], errors="coerce") - base_succ
        c = f"asof_pitcher_prev{w}_game_middle_rate"
        out[f"form_mid_{w}"] = pd.to_numeric(df[c], errors="coerce") - base_mid
    # 단기(1경기) vs 중기(5경기) 추세
    out["form_trend"] = out["form_succ_1"] - out["form_succ_5"]

    # ---- 6) 경험량 / cold-start 플래그 ----
    out["log_pitcher_n"] = np.log1p(pd.to_numeric(pn, errors="coerce").fillna(0))
    out["log_batter_n"] = np.log1p(pd.to_numeric(bn, errors="coerce").fillna(0))
    out["log_pitchmix_n"] = np.log1p(pd.to_numeric(mn, errors="coerce").fillna(0))
    out["pitcher_cold"] = (out["log_pitcher_n"] == 0).astype("int8")
    out["batter_cold"] = (out["log_batter_n"] == 0).astype("int8")

    # ---- 7) 투수 vs 타자 상호작용 ----
    out["pb_success_gap"] = (out["asof_pitcher_success_rate_sh"]
                             - out["asof_batter_success_rate_sh"])
    out["pb_middle_gap"] = (out["asof_pitcher_middle_rate_sh"]
                            - out["asof_batter_middle_rate_sh"])
    out["strike_minus_ball"] = (out["asof_pitcher_strike_rate_sh"]
                                - out["asof_pitcher_ball_rate_sh"])

    # ---- 8) 범주형: 학습 시 확정된 카테고리로 고정 (미지 값 → NaN=결측 처리) ----
    same_hand = None
    for c in RAW_CAT_COLS:
        cats = cfg["categories"].get(c)
        if c in df.columns and cats is not None:
            out[c] = pd.Categorical(df[c].astype("object"), categories=cats)
    if "pitcher_hand" in df.columns and "batter_hand" in df.columns:
        same_hand = (df["pitcher_hand"].astype("object")
                     == df["batter_hand"].astype("object")).astype("int8")
        out["same_handed"] = same_hand

    # ---- 9) 컬럼 순서 고정 + dtype 정리 ----
    feats = cfg.get("features") or list(out.columns)  # 최초 probe 시엔 자연 순서
    for c in feats:
        if c not in out.columns:
            out[c] = np.nan
    out = out[feats]
    num_cols = [c for c in feats if c not in RAW_CAT_COLS]
    out[num_cols] = out[num_cols].astype("float32")
    return out


# =======================
# 데이터 로드 유틸
# =======================

def load_test(path):
    df = pd.read_csv(path, encoding="utf-8-sig")
    if ID_COL not in df.columns:
        raise ValueError(f"test 데이터에 {ID_COL} 컬럼이 없음: {list(df.columns)[:5]}")
    return df


def load_sample_submission(path):
    df = pd.read_csv(path, encoding="utf-8-sig")
    if list(df.columns[:2]) != [ID_COL, TARGET_COL]:
        raise ValueError(
            f"sample_submission 컬럼이 ({ID_COL}, {TARGET_COL})이 아님: {list(df.columns)}")
    return df


def merge_predictions(sub, ids, preds):
    pred_map = dict(zip(ids, preds))
    values, n_missing = [], 0
    for rid, cur in zip(sub[ID_COL], sub[TARGET_COL]):
        p = pred_map.get(rid)
        if p is None:
            n_missing += 1
            values.append(cur)
        else:
            values.append(float(p))
    if n_missing:
        print(f" 경고: 예측이 없어 placeholder를 유지한 row_id {n_missing}건")
    sub[TARGET_COL] = values
    return sub


def save_submission(path, sub):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    sub.to_csv(path, index=False, encoding="utf-8")


# =======================
# main
# =======================

def main():
    TEST_DIR = "./data"
    MODEL_DIR = "./model"
    OUT_DIR = "./output"
    TEST_PATH = os.path.join(TEST_DIR, "test.csv")
    SAMPLE_SUB_PATH = os.path.join(TEST_DIR, "sample_submission.csv")
    MODEL_PATH = os.path.join(MODEL_DIR, "model.pkl")
    OUT_PATH = os.path.join(OUT_DIR, "submission.csv")

    print("Load model...")
    bundle = joblib.load(MODEL_PATH)
    models = bundle["models"]          # seed 앙상블 (리스트)
    cfg = bundle["cfg"]
    # calib: {"type": "platt", "a":.., "b":..} | {"type": "isotonic", "model": IsotonicRegression} | None
    calib = bundle.get("calibrator")
    print(f" OK. n_models={len(models)}  n_features={len(cfg['features'])}"
          f"  calibrator={calib['type'] if calib else 'none'}")

    print("Load test data...")
    test = load_test(TEST_PATH)
    sub = load_sample_submission(SAMPLE_SUB_PATH)
    print(f" test={len(test)}  submission={len(sub)}")

    print("Build features...")
    ids = test[ID_COL].tolist()
    X = build_features(test, cfg)
    print(f" features={X.shape[1]}")

    print("Inference...")
    if len(X):
        # 메모리 안정성을 위해 청크 단위 추론
        CHUNK = 200_000
        parts = []
        for i in range(0, len(X), CHUNK):
            xc = X.iloc[i:i + CHUNK]
            p = np.mean([m.predict_proba(xc)[:, 1] for m in models], axis=0)
            parts.append(p)
        preds = np.concatenate(parts)
        if calib is not None:
            if calib["type"] == "platt":
                a, b = calib["a"], calib["b"]
                z = np.log(np.clip(preds, 1e-6, 1 - 1e-6) / (1 - np.clip(preds, 1e-6, 1 - 1e-6)))
                preds = 1.0 / (1.0 + np.exp(-(a * z + b)))
            elif calib["type"] == "isotonic":
                preds = calib["model"].predict(preds)
        preds = np.clip(preds, 1e-6, 1 - 1e-6)
    else:
        preds = []
    print(f" preds={len(preds)}")

    print("Build submission...")
    sub = merge_predictions(sub, ids, preds)
    save_submission(OUT_PATH, sub)
    print(f"Saved: {OUT_PATH} (rows={len(sub)})")


if __name__ == "__main__":
    main()
