# script.py — 제출용 추론 코드 (submit.zip 최상위)
# ------------------------------------------------------------
# 평가 서버 실행 구조:
#   submit.zip/
#     ├── model/model.pkl   ← train.py 가 만든 번들
#     ├── script.py         ← 이 파일
#     ├── requirements.txt
#     ├── data/             ← 평가 서버가 주입 (읽기 전용)
#     └── output/submission.csv  ← 반드시 여기에 저장
#
# ※ build_features() 는 train.py 에서도 import 해서 쓴다.
#   (학습/추론 전처리 불일치 방지 — 단일 진실 공급원)
# ------------------------------------------------------------
import os

import joblib
import numpy as np
import pandas as pd

ID_COL = "row_id"
TARGET_COL = "control_success"

# 원본 범주형 컬럼 (pandas category dtype 으로 변환 → HistGB 가 네이티브 처리)
RAW_CAT_COLS = [
    "top_bottom",
    "game_type",
    "base_state",
    "pitcher_hand",
    "batter_hand",
    "pitcher_team_id",
    "batter_team_id",
]

# 모델 입력에서 제외할 컬럼
# - row_id: 식별자
# - pitcher_id / batter_id: 고카디널리티 ID. 선수 개인 정보는 asof_* 가 이미 담고 있고,
#   raw ID 를 그대로 넣으면 과적합 + 미지 선수 대응 불가 → 베이스라인에서는 제외.
DROP_COLS = [ID_COL, "pitcher_id", "batter_id"]


# =======================
# 피처 엔지니어링
# =======================

def _shrink(rate, n, prior, k):
    """표본 수 기반 베이지안 축소(shrinkage).

    표본이 적은 선수(cold-start)의 rate 를 전체 평균(prior)쪽으로 당겨준다.
    n=0 이면 정확히 prior 가 된다.
    """
    n = pd.to_numeric(n, errors="coerce").fillna(0.0)
    r = pd.to_numeric(rate, errors="coerce").fillna(prior)
    return (r * n + prior * k) / (n + k)


def build_features(df, cfg):
    """학습/추론 공통 전처리. 행 단위로만 계산 → 평가 데이터 행간 정보 사용 없음."""
    p = cfg["priors"]
    k = cfg["shrink_k"]
    out = pd.DataFrame(index=df.index)

    # ---- 1) 원본 수치 피처 그대로 통과 ----
    passthrough = [c for c in df.columns
                   if c not in DROP_COLS + RAW_CAT_COLS + [TARGET_COL]]
    for c in passthrough:
        out[c] = pd.to_numeric(df[c], errors="coerce")

    # ---- 2) 볼카운트 파생 ----
    b = out["balls_before"]
    s = out["strikes_before"]
    out["count_state"] = b * 3 + s                 # 0~11 고유 카운트 상태
    out["count_diff"] = s - b                      # +면 투수 유리
    out["is_two_strike"] = (s == 2).astype("int8")
    out["is_three_ball"] = (b == 3).astype("int8")
    out["is_full_count"] = ((b == 3) & (s == 2)).astype("int8")
    out["is_first_pitch"] = ((b == 0) & (s == 0)).astype("int8")
    # 투수가 유리하면 유인구(존 밖 유도) → 제구 성공 정의와 직결되는 핵심 신호
    out["pitcher_ahead"] = (s > b).astype("int8")

    # ---- 3) 상황/압박 파생 ----
    out["abs_score_diff"] = out["score_diff_pitcher_team"].abs()
    out["is_blowout"] = (out["abs_score_diff"] >= 5).astype("int8")
    out["is_close_game"] = (out["abs_score_diff"] <= 1).astype("int8")
    out["we_diff"] = out["home_win_expectancy"] - out["away_win_expectancy"]
    out["log_li"] = np.log1p(out["li"].clip(lower=0))
    out["is_late_inning"] = (out["inning"] >= 7).astype("int8")
    out["scoring_position"] = (
        (out["runner_on_2b"] > 0) | (out["runner_on_3b"] > 0)).astype("int8")
    # 주자 있으면 세트포지션 → 제구 난이도 변화
    out["has_runner"] = (out["num_runners_on"] > 0).astype("int8")
    out["risk_situation"] = out["scoring_position"] * out["is_close_game"]

    # ---- 4) asof_* 축소 보정 (cold-start 안정화) ----
    pn = df["asof_pitcher_n"]
    bn = df["asof_batter_n"]
    mn = df["asof_pitcher_pitchmix_n"]

    for col, prior_key in [
        ("asof_pitcher_success_rate", "p_success"),
        ("asof_pitcher_reverse_rate", "p_reverse"),
        ("asof_pitcher_middle_rate", "p_middle"),
        ("asof_pitcher_ball_rate", "p_ball"),
        ("asof_pitcher_strike_rate", "p_strike"),
    ]:
        out[col + "_sh"] = _shrink(df[col], pn, p[prior_key], k)

    for col, prior_key in [
        ("asof_batter_success_rate", "b_success"),
        ("asof_batter_middle_rate", "b_middle"),
    ]:
        out[col + "_sh"] = _shrink(df[col], bn, p[prior_key], k)

    for col, prior_key in [
        ("asof_pitcher_fastball_rate", "p_fastball"),
        ("asof_pitcher_breaking_rate", "p_breaking"),
        ("asof_pitcher_offspeed_rate", "p_offspeed"),
    ]:
        out[col + "_sh"] = _shrink(df[col], mn, p[prior_key], k)

    # ---- 5) 최근 폼 (직전 N경기 - 통산) ----
    base_succ = out["asof_pitcher_success_rate_sh"]
    base_mid = out["asof_pitcher_middle_rate_sh"]
    for w in (1, 3, 5):
        c = f"asof_pitcher_prev{w}_game_success_rate"
        out[f"form_succ_{w}"] = pd.to_numeric(df[c], errors="coerce") - base_succ
        c = f"asof_pitcher_prev{w}_game_middle_rate"
        out[f"form_mid_{w}"] = pd.to_numeric(df[c], errors="coerce") - base_mid
    # 단기(1경기) vs 중기(5경기) 추세
    out["form_trend"] = out["form_succ_1"] - out["form_succ_5"]

    # ---- 6) 경험량 / cold-start 플래그 ----
    out["log_pitcher_n"] = np.log1p(pd.to_numeric(pn, errors="coerce").fillna(0))
    out["log_batter_n"] = np.log1p(pd.to_numeric(bn, errors="coerce").fillna(0))
    out["log_pitchmix_n"] = np.log1p(pd.to_numeric(mn, errors="coerce").fillna(0))
    out["pitcher_cold"] = (out["log_pitcher_n"] == 0).astype("int8")
    out["batter_cold"] = (out["log_batter_n"] == 0).astype("int8")

    # ---- 7) 투수 vs 타자 상호작용 ----
    out["pb_success_gap"] = (out["asof_pitcher_success_rate_sh"]
                             - out["asof_batter_success_rate_sh"])
    out["pb_middle_gap"] = (out["asof_pitcher_middle_rate_sh"]
                            - out["asof_batter_middle_rate_sh"])
    out["strike_minus_ball"] = (out["asof_pitcher_strike_rate_sh"]
                                - out["asof_pitcher_ball_rate_sh"])

    # ---- 8) 범주형: 학습 시 확정된 카테고리로 고정 (미지 값 → NaN=결측 처리) ----
    same_hand = None
    for c in RAW_CAT_COLS:
        cats = cfg["categories"].get(c)
        if c in df.columns and cats is not None:
            out[c] = pd.Categorical(df[c].astype("object"), categories=cats)
    if "pitcher_hand" in df.columns and "batter_hand" in df.columns:
        same_hand = (df["pitcher_hand"].astype("object")
                     == df["batter_hand"].astype("object")).astype("int8")
        out["same_handed"] = same_hand

    # ---- 8.5) Trackman 프로파일 결합 (투수손 x 타자손 x 볼카운트 x 아웃, 계층적 폴백) ----
    # cfg["trackman_profile"]: 상황별 리그 평균(2019~2024 통합). 개별 선수 비식별.
    # season을 키로 쓰지 않아 test season과 무관하게 항상 매칭됨.
    out = out.copy()  # 컬럼 다수 추가 전 조각모음 (PerformanceWarning 방지)
    tm_cols = ["fb_velo", "fb_spin", "fb_ivb", "fb_hb", "fb_ext", "fb_relh", "fb_rels",
               "brk_velo", "brk_spin", "brk_ivb", "brk_hb", "brk_ext", "brk_relh", "brk_rels",
               "fb_share"]
    TM_KEYS = ["pitcher_hand", "batter_hand", "balls_before", "strikes_before", "outs_before"]
    tm_profile = cfg.get("trackman_profile")
    if tm_profile is not None and all(k in df.columns for k in TM_KEYS):
        key = pd.DataFrame({
            "pitcher_hand": df["pitcher_hand"].astype("object").astype(str).values,
            "batter_hand": df["batter_hand"].astype("object").astype(str).values,
            "balls_before": pd.to_numeric(df["balls_before"], errors="coerce")
                              .clip(0, 3).astype("Int64").values,
            "strikes_before": pd.to_numeric(df["strikes_before"], errors="coerce")
                                .clip(0, 2).astype("Int64").values,
            "outs_before": pd.to_numeric(df["outs_before"], errors="coerce")
                             .clip(0, 2).astype("Int64").values,
        })
        prof = tm_profile.copy()
        # 손잡이 키는 양쪽 모두 문자열로 통일 (메인 코드가 숫자여도 안전하게 매칭)
        prof["pitcher_hand"] = prof["pitcher_hand"].astype(str)
        prof["batter_hand"] = prof["batter_hand"].astype(str)
        for c in ("balls_before", "strikes_before", "outs_before"):
            prof[c] = prof[c].astype("Int64")
        merged = key.merge(prof, on=TM_KEYS, how="left")
        # 조인 성공률 진단 — 손잡이 표기 불일치 등으로 조용히 실패하는 것을 방지
        if len(merged) and "fb_velo" in merged.columns:
            match_rate = float(merged["fb_velo"].notna().mean())
            if match_rate < 0.99:
                print(f" ⚠️ [trackman] 조인 매칭률 {match_rate:.1%} — "
                      f"키 값 불일치 가능성. 해당 피처가 결측 처리됩니다.")
        for c in tm_cols:
            out["tm_" + c] = (merged[c].to_numpy(dtype="float32")
                              if c in merged.columns else np.nan)
        # 구종 간 격차 — 격차가 클수록 제구 난이도/타자 대응이 달라짐
        out["tm_velo_gap"] = out["tm_fb_velo"] - out["tm_brk_velo"]
        out["tm_ivb_gap"] = out["tm_fb_ivb"] - out["tm_brk_ivb"]
        out["tm_hb_gap"] = out["tm_fb_hb"] - out["tm_brk_hb"]
        # 릴리스 포인트 일관성 — 직구/변화구 릴리스가 다르면 타자에게 읽히고 제구도 흔들림
        out["tm_relh_gap"] = out["tm_fb_relh"] - out["tm_brk_relh"]
        out["tm_rels_gap"] = out["tm_fb_rels"] - out["tm_brk_rels"]
        # 투수 개인 구종성향(asof) vs 해당 상황의 리그 평균 성향 차이
        fb_rate_sh = out.get("asof_pitcher_fastball_rate_sh")
        out["tm_fb_share_dev"] = (fb_rate_sh - out["tm_fb_share"]
                                  if fb_rate_sh is not None else np.nan)
        # 투수 구종비율로 가중한 "체감" 물리값
        fb_rate = out.get("asof_pitcher_fastball_rate_sh", pd.Series(0.5, index=out.index))
        brk_rate = out.get("asof_pitcher_breaking_rate_sh", pd.Series(0.3, index=out.index))
        denom = (fb_rate + brk_rate).replace(0, np.nan)
        out["tm_blend_velo"] = ((out["tm_fb_velo"] * fb_rate + out["tm_brk_velo"] * brk_rate) / denom)
        out["tm_blend_spin"] = ((out["tm_fb_spin"] * fb_rate + out["tm_brk_spin"] * brk_rate) / denom)
    else:
        for c in tm_cols:
            out["tm_" + c] = np.nan
        for c in ["tm_velo_gap", "tm_ivb_gap", "tm_hb_gap", "tm_relh_gap", "tm_rels_gap",
                  "tm_fb_share_dev", "tm_blend_velo", "tm_blend_spin"]:
            out[c] = np.nan

    # ---- 9) 컬럼 순서 고정 + dtype 정리 ----
    feats = cfg.get("features") or list(out.columns)  # 최초 probe 시엔 자연 순서
    for c in feats:
        if c not in out.columns:
            out[c] = np.nan
    out = out[feats]
    num_cols = [c for c in feats if c not in RAW_CAT_COLS]
    out[num_cols] = out[num_cols].astype("float32")
    return out


# =======================
# 데이터 로드 유틸
# =======================

def load_test(path):
    df = pd.read_csv(path, encoding="utf-8-sig")
    if ID_COL not in df.columns:
        raise ValueError(f"test 데이터에 {ID_COL} 컬럼이 없음: {list(df.columns)[:5]}")
    return df


def load_sample_submission(path):
    df = pd.read_csv(path, encoding="utf-8-sig")
    if list(df.columns[:2]) != [ID_COL, TARGET_COL]:
        raise ValueError(
            f"sample_submission 컬럼이 ({ID_COL}, {TARGET_COL})이 아님: {list(df.columns)}")
    return df


def merge_predictions(sub, ids, preds):
    pred_map = dict(zip(ids, preds))
    values, n_missing = [], 0
    for rid, cur in zip(sub[ID_COL], sub[TARGET_COL]):
        p = pred_map.get(rid)
        if p is None:
            n_missing += 1
            values.append(cur)
        else:
            values.append(float(p))
    if n_missing:
        print(f" 경고: 예측이 없어 placeholder를 유지한 row_id {n_missing}건")
    sub[TARGET_COL] = values
    return sub


def save_submission(path, sub):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    sub.to_csv(path, index=False, encoding="utf-8")


# =======================
# main
# =======================


# =======================
# CatBoost 보조 모델
# =======================

CAT_BLEND_WEIGHT = 0.55  # 기존 HGBT 45% + CatBoost 55%


def build_cat_features(df, meta):
    """CatBoost용 경량 피처. 모든 계산은 현재 행 정보만 사용한다."""
    cols = meta["columns"]
    cat_cols = meta["cat_cols"]
    maps = meta["maps"]

    # 필요한 원본 컬럼만 복사. object 문자열은 미리 정수 코드화해 메모리 절약.
    raw_needed = [c for c in df.columns if c not in [ID_COL, TARGET_COL]]
    x = df[raw_needed].copy()

    for c, mp in maps.items():
        if c in x.columns:
            x[c] = x[c].map(mp).fillna(-1).astype("int16")

    # 기본 수치형 compact cast
    for c in x.columns:
        if c in cat_cols or c in maps:
            continue
        x[c] = pd.to_numeric(x[c], errors="coerce")

    b = pd.to_numeric(x["balls_before"], errors="coerce")
    s = pd.to_numeric(x["strikes_before"], errors="coerce")
    x["count_state"] = b * 3 + s
    x["count_diff"] = s - b
    x["is_full_count"] = ((b == 3) & (s == 2)).astype("int8")
    x["is_first_pitch"] = ((b == 0) & (s == 0)).astype("int8")
    x["pitcher_ahead"] = (s > b).astype("int8")
    x["abs_score_diff"] = pd.to_numeric(x["score_diff_pitcher_team"], errors="coerce").abs()
    x["is_close_game"] = (x["abs_score_diff"] <= 1).astype("int8")
    x["scoring_position"] = (
        (pd.to_numeric(x["runner_on_2b"], errors="coerce") > 0)
        | (pd.to_numeric(x["runner_on_3b"], errors="coerce") > 0)
    ).astype("int8")
    x["same_handed"] = (
        pd.to_numeric(x["pitcher_hand"], errors="coerce")
        == pd.to_numeric(x["batter_hand"], errors="coerce")
    ).astype("int8")
    x["pb_success_gap"] = (
        pd.to_numeric(x["asof_pitcher_success_rate"], errors="coerce")
        - pd.to_numeric(x["asof_batter_success_rate"], errors="coerce")
    )
    x["pb_middle_gap"] = (
        pd.to_numeric(x["asof_pitcher_middle_rate"], errors="coerce")
        - pd.to_numeric(x["asof_batter_middle_rate"], errors="coerce")
    )
    for w in (1, 3, 5):
        x[f"form_succ_{w}"] = (
            pd.to_numeric(x[f"asof_pitcher_prev{w}_game_success_rate"], errors="coerce")
            - pd.to_numeric(x["asof_pitcher_success_rate"], errors="coerce")
        )
    x["form_trend"] = (
        pd.to_numeric(x["asof_pitcher_prev1_game_success_rate"], errors="coerce")
        - pd.to_numeric(x["asof_pitcher_prev5_game_success_rate"], errors="coerce")
    )

    # CatBoost categorical columns must not contain NaN and should be stable token values.
    for c in cat_cols:
        if c in x.columns:
            x[c] = pd.to_numeric(x[c], errors="coerce").fillna(-1).astype("int32")

    # 나머지 수치형은 float32로 축소
    for c in cols:
        if c not in x.columns:
            x[c] = np.nan
        if c not in cat_cols:
            x[c] = pd.to_numeric(x[c], errors="coerce").astype("float32")

    return x[cols]


def apply_hgb_postprocess(preds, test, bundle):
    calib = bundle.get("calibrator")
    shift = bundle.get("shift")
    calib_segment = bundle.get("calib_segment")

    if calib is not None:
        if calib["type"] == "platt":
            a, b = calib["a"], calib["b"]
            z = np.log(np.clip(preds, 1e-6, 1 - 1e-6) / (1 - np.clip(preds, 1e-6, 1 - 1e-6)))
            preds = 1.0 / (1.0 + np.exp(-(a * z + b)))
        elif calib["type"] == "isotonic":
            preds = calib["model"].predict(preds)
        elif calib["type"] == "segmented":
            seg = (test[calib_segment].astype(str).to_numpy()
                   if calib_segment and calib_segment in test.columns
                   else np.array(["_"] * len(preds)))
            out = calib["global"].predict(preds)
            for sname, iso in calib["models"].items():
                m = seg == sname
                if m.any():
                    out[m] = iso.predict(preds[m])
            preds = out

    if shift is not None:
        z = np.log(np.clip(preds, 1e-6, 1 - 1e-6) / (1 - np.clip(preds, 1e-6, 1 - 1e-6)))
        preds = 1.0 / (1.0 + np.exp(-(z + shift["b"])))

    # 기존 876 제출물은 pred_shrink=1.0. 평가 test 전체 평균을 사용하지 않도록
    # hybrid에서는 shrink를 의도적으로 적용하지 않는다.
    return np.clip(preds, 1e-6, 1 - 1e-6)


def main():
    import gc
    from catboost import CatBoostClassifier

    TEST_DIR = "./data"
    MODEL_DIR = "./model"
    OUT_DIR = "./output"
    TEST_PATH = os.path.join(TEST_DIR, "test.csv")
    SAMPLE_SUB_PATH = os.path.join(TEST_DIR, "sample_submission.csv")
    HGB_PATH = os.path.join(MODEL_DIR, "model.pkl")
    CAT_PATH = os.path.join(MODEL_DIR, "catboost.cbm")
    CAT_META_PATH = os.path.join(MODEL_DIR, "catboost_meta.pkl")
    CAT_PLATT_PATH = os.path.join(MODEL_DIR, "cat_platt.pkl")
    OUT_PATH = os.path.join(OUT_DIR, "submission.csv")

    print("Load models...")
    bundle = joblib.load(HGB_PATH)
    models = bundle["models"]
    cfg = bundle["cfg"]
    cat_meta = joblib.load(CAT_META_PATH)
    cat_platt = joblib.load(CAT_PLATT_PATH)
    cat_model = CatBoostClassifier()
    cat_model.load_model(CAT_PATH)
    print(f" HGBT={len(models)} models, CatBoost=1, cat_weight={CAT_BLEND_WEIGHT:.2f}")

    print("Load test data...")
    test = load_test(TEST_PATH)
    sub = load_sample_submission(SAMPLE_SUB_PATH)
    ids = test[ID_COL].tolist()
    print(f" test={len(test)}  submission={len(sub)}")

    # ---- 1) 기존 876 HGBT 예측 ----
    print("HGBT features + inference...")
    Xh = build_features(test, cfg)
    CHUNK = 100_000
    parts = []
    linear = bundle.get("linear")
    blend_w = float(bundle.get("blend_w") or 0.0)
    for i in range(0, len(Xh), CHUNK):
        xc = Xh.iloc[i:i + CHUNK]
        p = np.mean([m.predict_proba(xc)[:, 1] for m in models], axis=0)
        if linear is not None and blend_w > 0:
            xl = xc.copy()
            for c in xl.columns:
                if str(xl[c].dtype) == "category":
                    xl[c] = xl[c].cat.codes.replace(-1, np.nan)
            p_lin = linear.predict_proba(xl.astype("float32"))[:, 1]
            p = (1 - blend_w) * p + blend_w * p_lin
        parts.append(p.astype("float32"))
    p_hgb = np.concatenate(parts) if parts else np.array([], dtype="float32")
    p_hgb = apply_hgb_postprocess(p_hgb, test, bundle)
    del Xh, parts
    gc.collect()
    print(f" HGBT mean={p_hgb.mean():.5f} std={p_hgb.std():.5f}")

    # ---- 2) CatBoost 보조 예측 ----
    print("CatBoost features + inference...")
    Xc = build_cat_features(test, cat_meta)
    cat_parts = []
    cat_cols = cat_meta["cat_cols"]
    for i in range(0, len(Xc), CHUNK):
        xc = Xc.iloc[i:i + CHUNK]
        pc = cat_model.predict_proba(xc, thread_count=6)[:, 1]
        cat_parts.append(pc.astype("float32"))
    p_cat = np.concatenate(cat_parts) if cat_parts else np.array([], dtype="float32")
    # CatBoost 2024 holdout 기반 Platt calibration
    z = np.log(np.clip(p_cat, 1e-6, 1 - 1e-6) / (1 - np.clip(p_cat, 1e-6, 1 - 1e-6)))
    p_cat = 1.0 / (1.0 + np.exp(-(float(cat_platt["a"]) * z + float(cat_platt["b"]))))
    del Xc, cat_parts
    gc.collect()
    print(f" CatBoost mean={p_cat.mean():.5f} std={p_cat.std():.5f}")

    # ---- 3) 보수적 모델 블렌딩 ----
    preds = (1.0 - CAT_BLEND_WEIGHT) * p_hgb + CAT_BLEND_WEIGHT * p_cat
    preds = np.clip(preds, 1e-6, 1 - 1e-6)
    print(f" Hybrid mean={preds.mean():.5f} std={preds.std():.5f}")

    print("Build submission...")
    sub = merge_predictions(sub, ids, preds)
    save_submission(OUT_PATH, sub)
    print(f"Saved: {OUT_PATH} (rows={len(sub)})")


if __name__ == "__main__":
    main()
